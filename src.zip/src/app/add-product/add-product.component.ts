import { Component } from '@angular/core';
import { Product } from '../interface/product';
import { FormGroup, FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {
  product: FormGroup;
  constructor(private fb: FormBuilder){
    this.product = this.fb.group({
      productId: [''],
      productName: [''],
      productCode: [''],
      releaseDate: [''],
      description: [''],
      price: [''],
      starRating: [''],
      imageUrl: [''],
    });
  }
}
