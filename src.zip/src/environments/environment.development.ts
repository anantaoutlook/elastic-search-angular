export const environment = {
    api_url: 'http://localhost:8081/productservice'
};
